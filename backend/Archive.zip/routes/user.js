var express = require('express');
var router = express.Router();
var mongojs = require('mongojs');
var ObjectId = require('mongodb').ObjectID; 
var db = mongojs('mongodb://eash:Issiutng123@ds017514.mlab.com:17514/dmakvids2018', ['comments']);

/*router.post("/login" (req, res, next) => {

});*/

module.exports = router; 